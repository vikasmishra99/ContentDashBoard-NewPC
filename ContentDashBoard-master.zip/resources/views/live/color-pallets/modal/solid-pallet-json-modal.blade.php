<div class="card">
    <div class="card-header">
        <h3 class="card-title">Card with code</h3>
    </div>
    <div class="card-code">
        <figure class="highlight">
                          <pre><code class="language-scss" data-lang="scss"><span class="nc">.card-footer</span> <span class="p">{</span>
	<span class="nl">background</span><span class="p">:</span> <span class="nb">transparent</span><span class="p">;</span>

	<span class="k">&amp;</span><span class="nd">:last-child</span> <span class="p">{</span>
		<span class="nl">border-radius</span><span class="p">:</span> <span class="m">0</span> <span class="m">0</span> <span class="m">1</span> <span class="m">2</span><span class="p">;</span>
	<span class="p">}</span>
<span class="p">}</span></code></pre>
        </figure>
    </div>
</div>
