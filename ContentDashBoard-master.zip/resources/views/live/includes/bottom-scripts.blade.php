<script src="{{asset('dist/js/tabler.min.js')}}" defer></script>
<script src="{{asset('dist/js/demo.min.js')}}" defer></script>