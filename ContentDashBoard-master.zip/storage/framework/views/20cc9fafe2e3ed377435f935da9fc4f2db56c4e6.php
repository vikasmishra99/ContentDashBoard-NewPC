<!-- Red Color -->
<div class=" card mb-4">
    <div class="card-header bg-red">
        <div>
            <h3 class="card-title">
                Pallet Name : Red
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
   
    </div>
    <div class="card-body bg-white">
        <div class="row g-2">
            <div class="col-auto avatar rounded-circle bg-red m-1"></div>
            <div class="col-auto avatar rounded-circle bg-red m-1"></div>
            <div class="col-auto avatar rounded-circle bg-red m-1"></div>
            <div class="col-auto avatar rounded-circle bg-red m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-red m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-red m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-red m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-red m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-red m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-red m-1">
            </div>
        </div>
    </div>
</div>

<!-- Green Color -->
<div class=" card mb-4">
    <div class="card-header bg-green">
        <div>
            <h3 class="card-title">
                Pallet Name : Green
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body bg-white">
        <div class="row g-2">
            <div class="col-auto avatar rounded-circle bg-green m-1"></div>
            <div class="col-auto avatar rounded-circle bg-green m-1"></div>
            <div class="col-auto avatar rounded-circle bg-green m-1"></div>
            <div class="col-auto avatar rounded-circle bg-green m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-green m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-green m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-green m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-green m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-green m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-green m-1">
            </div>
        </div>
    </div>
</div>

<!-- Blue Color -->
<div class=" card mb-4">
    <div class="card-header bg-blue">
        <div>
            <h3 class="card-title">
                Pallet Name : Green
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body bg-white">
        <div class="row g-2">
            <div class="col-auto avatar rounded-circle bg-blue m-1"></div>
            <div class="col-auto avatar rounded-circle bg-blue m-1"></div>
            <div class="col-auto avatar rounded-circle bg-blue m-1"></div>
            <div class="col-auto avatar rounded-circle bg-blue m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-blue m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-blue m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-blue m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-blue m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-blue m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-blue m-1">
            </div>
        </div>
    </div>
</div>

<!-- Yellow Color -->
<div class=" card mb-4">
    <div class="card-header bg-yellow">
        <div>
            <h3 class="card-title">
                Pallet Name : Green
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body bg-white">
        <div class="row g-2">
            <div class="col-auto avatar rounded-circle bg-yellow m-1"></div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1"></div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1"></div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-yellow m-1">
            </div>
        </div>
    </div>
</div>

<!-- Purple Color -->
<div class=" card mb-4">
    <div class="card-header bg-purple">
        <div>
            <h3 class="card-title">
                Pallet Name : Green
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body bg-white">
        <div class="row g-2">
            <div class="col-auto avatar rounded-circle bg-purple m-1"></div>
            <div class="col-auto avatar rounded-circle bg-purple m-1"></div>
            <div class="col-auto avatar rounded-circle bg-purple m-1"></div>
            <div class="col-auto avatar rounded-circle bg-purple m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-purple m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-purple m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-purple m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-purple m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-purple m-1">
            </div>
            <div class="col-auto avatar rounded-circle bg-purple m-1">
            </div>
        </div>
    </div>
</div>



<?php /**PATH S:\WebDev\htdocs\ContentDashBoard-master\resources\views/live/color-pallets/includes/solid-color-pallets.blade.php ENDPATH**/ ?>