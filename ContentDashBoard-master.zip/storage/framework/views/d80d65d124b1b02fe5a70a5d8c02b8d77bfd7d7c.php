<div class="modal modal-blur fade" id="slider-success-alert" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
                <div class="alert alert-success alert-dismissible" role="alert">
                    <h3 class="alert-title">Wow! 'Category Title' category  is successfully added to home slider</h3>
                    <p>You can remove 'Category Title' category from slider anytime by just switching it off</p>
                    <div class="btn-list">
                        <a href="javascript:void(0)" class="btn btn-success">Okay</a>
                        <a href="javascript:void(0)" class="btn">Cancel</a>
                    </div>
                    <a class="btn-close" data-bs-dismiss="alert" aria-label="close"></a>
                </div>
    </div>
</div><?php /**PATH S:\WebDev\htdocs\ContentDashBoard-master\resources\views/live/coloringbook/modals/categories/slider-sucess-alert.blade.php ENDPATH**/ ?>