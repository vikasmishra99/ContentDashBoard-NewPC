<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>Color Pallets UI</title>
    <?php echo $__env->make('live.includes.top-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body >
<div class="page">
    <?php echo $__env->make('live.coloringbook.includes.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="container-xl">
            <!-- Page title -->
            <div class="page-header d-print-none">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <h2 class="page-title">
                            Basic Color Pallets
                        </h2>
                    </div>

                </div>
            </div>
        </div>
        <div class="page-body">
            <div class="container-xl">
              <?php echo $__env->make('live.color-pallets.includes.basic-color-pallets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('live.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<!-- Libs JS -->
<?php echo $__env->make('live.includes.bottom-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></body>
</html>
<?php /**PATH S:\WebDev\htdocs\ContentDashBoard-master\resources\views/live/color-pallets/solid-pallet-ui.blade.php ENDPATH**/ ?>
