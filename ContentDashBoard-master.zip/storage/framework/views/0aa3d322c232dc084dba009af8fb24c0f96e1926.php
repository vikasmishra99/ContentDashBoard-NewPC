<?php /**PATH S:\WebDev\htdocs\ContentDashBoard-master\resources\views/live/color-pallets/modal/create-pallet-modal.blade.php ENDPATH**/ ?>
