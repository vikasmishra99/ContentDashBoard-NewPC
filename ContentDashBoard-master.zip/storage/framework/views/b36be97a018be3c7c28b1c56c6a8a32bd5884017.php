<!-- Red Color -->
<div class="col-md-6 col-xl-4">
    <div class="row row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-red">
                    <div>
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="card-title">Pallet Name : Red</div>
                                <div class="card-subtitle text-white">Pallet Type : color</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>

                    </div>
                    <div class="card-footer">
                        <div class="d-flex">
                            <a href="#" class="btn btn-link" data-bs-toggle="modal"
                               data-bs-target="#edit-pallet-modal-items">Edit pallet details</a>
                            <a href="#" class="btn btn-primary text-white ms-auto" data-bs-toggle="modal"
                               data-bs-target="#paste-color-items">Add Color Items</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Green Color -->
<div class="col-md-6 col-xl-4">
    <div class="row row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-green">
                    <div>
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="card-title">Pallet Name : Green</div>
                                <div class="card-subtitle text-white">Pallet Type : color</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>

                    </div>
                    <div class="card-footer">
                        <div class="d-flex">
                            <a href="#" class="btn btn-link" data-bs-toggle="modal"
                               data-bs-target="#edit-pallet-modal-items">Edit pallet details</a>
                            <a href="#" class="btn btn-primary text-white ms-auto" data-bs-toggle="modal"
                               data-bs-target="#paste-color-items">Add Color Items</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Blue Color -->
<div class="col-md-6 col-xl-4">
    <div class="row row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-blue">
                    <div>
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="card-title">Pallet Name : Blue</div>
                                <div class="card-subtitle text-white">Pallet Type : color</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>

                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex">
                        <a href="#" class="btn btn-link" data-bs-toggle="modal"
                           data-bs-target="#edit-pallet-modal-items">Edit pallet details</a>
                        <a href="#" class="btn btn-primary text-white ms-auto" data-bs-toggle="modal"
                           data-bs-target="#paste-color-items">Add Color Items</a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Yellow Color -->
<div class="col-md-6 col-xl-4">
    <div class="row row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-yellow">
                    <div>
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="card-title">Pallet Name : Yellow</div>
                                <div class="card-subtitle text-white">Pallet Type : color</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>

                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex">
                        <a href="#" class="btn btn-link" data-bs-toggle="modal"
                           data-bs-target="#edit-pallet-modal-items">Edit pallet details</a>
                        <a href="#" class="btn btn-primary text-white ms-auto" data-bs-toggle="modal"
                           data-bs-target="#paste-color-items">Add Color Items</a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Purple Color -->
<div class="col-md-6 col-xl-4">
    <div class="row row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-purple">
                    <div>
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="card-title">Pallet Name : Purple</div>
                                <div class="card-subtitle text-white">Pallet Type : color</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>
                        <div class="col-auto avatar rounded-circle bg-red m-1"></div>

                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex">
                        <a href="#" class="btn btn-link" data-bs-toggle="modal"
                           data-bs-target="#edit-pallet-modal-items">Edit pallet details</a>
                        <a href="#" class="btn btn-primary text-white ms-auto" data-bs-toggle="modal"
                           data-bs-target="#paste-color-items">Add Color Items</a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>



<?php /**PATH D:\WebDev\htdocs\ContentDashBoard-master\ContentDashBoard-master\resources\views/live/color-pallets/includes/solid-color-pallets.blade.php ENDPATH**/ ?>