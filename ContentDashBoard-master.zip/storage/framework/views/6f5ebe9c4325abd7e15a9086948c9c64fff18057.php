<!-- CSS files -->
<link href="<?php echo e(asset('dist/css/tabler.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('dist/css/tabler-flags.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('dist/css/tabler-payments.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('dist/css/tabler-vendors.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(asset('dist/css/demo.min.css')); ?>" rel="stylesheet"/><?php /**PATH D:\WebDev\htdocs\ContentDashBoard-master\ContentDashBoard-master\resources\views/live/includes/top-scripts.blade.php ENDPATH**/ ?>