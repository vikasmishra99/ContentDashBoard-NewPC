
<!-- Red Color -->
<div class="card mb-4">
    <div class="card-header bg-red">
        <div>
            <h3 class="card-title">
                Pallet Name : Red
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table text-center">
                <tr>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-red" data-demo-color>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>

<!-- Green Color -->
<div class="card mb-4">
    <div class="card-header bg-green">
        <div>
            <h3 class="card-title">
                Pallet Name : Green
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table text-center">
                <tr>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-green" data-demo-color>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>

<!-- Blue Color -->
<div class="card mb-4">
    <div class="card-header bg-blue">
        <div>
            <h3 class="card-title">
                Pallet Name : Blue
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table text-center">
                <tr>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-blue" data-demo-color>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>

<!-- Yellow Color -->
<div class="card mb-4">
    <div class="card-header bg-yellow">
        <div>
            <h3 class="card-title">
                Pallet Name : Yellow
            </h3>
            <p class="card-subtitle text-white">
                Pallet Type : Color
            </p>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table text-center">
                <tr>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                    <td>
                        <div class="avatar rounded-circle  text-white bg-yellow" data-demo-color>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>
<?php /**PATH S:\WebDev\htdocs\ContentDashBoard-master\resources\views/live/color-pallets/includes/solid-color-pallets.blade.php ENDPATH**/ ?>
